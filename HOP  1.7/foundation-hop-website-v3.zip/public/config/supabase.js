
/**
 * Supabase client
 * 1) Create a project at https://supabase.com/
 * 2) Paste your URL + anon key below
 * 3) (Recommended) Turn on RLS policies from README instructions
 */
/* global supabase */
window.SUPABASE_URL = "YOUR_SUPABASE_URL";
window.SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
window.db = supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
