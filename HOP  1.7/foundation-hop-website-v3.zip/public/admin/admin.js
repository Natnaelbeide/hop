
/* global db, SiteData */
(function(){
  const ADMIN_EMAIL = "beidenatnael@gmail.com";

  // Elements
  const loginWrap = document.getElementById("admin-login");
  const appWrap = document.getElementById("admin-app");
  const loginBtn = document.getElementById("login-btn");
  const logoutBtn = document.getElementById("logout-btn");
  const msgEl = document.getElementById("login-msg");

  const emailEl = document.getElementById("admin-email");
  const passEl = document.getElementById("admin-password");

  function setMsg(el, text){ if (el) el.textContent = text || ""; }

  function requireSupabase(){
    return db && window.SUPABASE_URL && window.SUPABASE_URL !== "YOUR_SUPABASE_URL";
  }

  async function getUser(){
    if (!requireSupabase()) return null;
    const { data } = await db.auth.getUser();
    return data?.user || null;
  }

  async function isAdmin(){
    const u = await getUser();
    return !!(u && u.email === ADMIN_EMAIL);
  }

  async function showAppIfAdmin(){
    const ok = await isAdmin();
    if (ok){
      loginWrap.style.display = "none";
      appWrap.style.display = "block";
      logoutBtn.style.display = "inline-flex";
      await initAdmin();
      return true;
    } else {
      loginWrap.style.display = "block";
      appWrap.style.display = "none";
      logoutBtn.style.display = "none";
      return false;
    }
  }

  async function login(){
    if (!requireSupabase()){
      setMsg(msgEl, "Supabase is not connected yet. Update /public/config/supabase.js");
      return;
    }

    const email = (emailEl.value || "").trim();
    const password = (passEl.value || "").trim();

    if (!email || !password){
      setMsg(msgEl, "Enter email and password.");
      return;
    }

    setMsg(msgEl, "Signing in...");
    loginBtn.disabled = true;

    const { data, error } = await db.auth.signInWithPassword({ email, password });

    loginBtn.disabled = false;

    if (error){
      setMsg(msgEl, "Login failed.");
      return;
    }

    if (data?.user?.email !== ADMIN_EMAIL){
      await db.auth.signOut();
      setMsg(msgEl, "Not authorized.");
      return;
    }

    setMsg(msgEl, "");
    await showAppIfAdmin();
  }

  async function logout(){
    if (!requireSupabase()) return;
    await db.auth.signOut();
    setMsg(msgEl, "Signed out.");
    await showAppIfAdmin();
  }

  // ========= Settings =========
  const setChurchName = document.getElementById("set-church-name");
  const setHeroSubtitle = document.getElementById("set-hero-subtitle");
  const setHeroCta = document.getElementById("set-hero-cta");
  const setFriday = document.getElementById("set-service-friday");
  const setSunday = document.getElementById("set-service-sunday");
  const setAddress = document.getElementById("set-address");
  const setZelle = document.getElementById("set-zelle");
  const setCash = document.getElementById("set-cashapp");
  const setStripe = document.getElementById("set-stripe-url");
  const saveSettingsBtn = document.getElementById("save-settings");
  const settingsMsg = document.getElementById("settings-msg");

  async function loadSettings(){
    const s = await SiteData.getSettings();
    setChurchName.value = s.church_name || "";
    setHeroSubtitle.value = s.hero_subtitle || "";
    setHeroCta.value = s.hero_cta || "";
    setFriday.value = s.service_friday || "";
    setSunday.value = s.service_sunday || "";
    setAddress.value = s.address || "";
    setZelle.value = s.giving_zelle || "";
    setCash.value = s.giving_cashapp || "";
    setStripe.value = s.giving_stripe_url || "";
  }

  async function saveSettings(){
    setMsg(settingsMsg, "Saving...");
    const rows = [
      { key: "church_name", value: setChurchName.value.trim() },
      { key: "hero_subtitle", value: setHeroSubtitle.value.trim() },
      { key: "hero_cta", value: setHeroCta.value.trim() },
      { key: "service_friday", value: setFriday.value.trim() },
      { key: "service_sunday", value: setSunday.value.trim() },
      { key: "address", value: setAddress.value.trim() },
      { key: "giving_zelle", value: setZelle.value.trim() },
      { key: "giving_cashapp", value: setCash.value.trim() },
      { key: "giving_stripe_url", value: setStripe.value.trim() },
    ];

    const { error } = await db.from("site_settings").upsert(rows, { onConflict: "key" });
    if (error){
      setMsg(settingsMsg, "Save failed.");
      return;
    }
    setMsg(settingsMsg, "Saved.");
  }

  // ========= Gallery =========
  const gFile = document.getElementById("gallery-file");
  const gCaption = document.getElementById("gallery-caption");
  const gUploadBtn = document.getElementById("upload-btn");
  const gMsg = document.getElementById("gallery-msg");
  const gList = document.getElementById("gallery-list");

  function escapeHtml(s){
    return (s || "").replace(/[&<>"']/g, (c)=>({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[c]));
  }

  async function maxSort(table){
    const { data } = await db.from(table).select("sort_order").order("sort_order", { ascending: false }).limit(1);
    return (data && data[0] && data[0].sort_order) ? data[0].sort_order : 0;
  }

  async function uploadGallery(){
    const file = gFile.files && gFile.files[0];
    if (!file){ setMsg(gMsg, "Choose an image."); return; }

    setMsg(gMsg, "Uploading...");
    gUploadBtn.disabled = true;

    const ext = (file.name.split(".").pop() || "png").toLowerCase();
    const path = `gallery/${crypto.randomUUID()}.${ext}`;

    const up = await db.storage.from("gallery").upload(path, file, { upsert: false, contentType: file.type });
    if (up.error){
      gUploadBtn.disabled = false;
      setMsg(gMsg, "Upload failed. Check Storage bucket + policies.");
      return;
    }

    const pub = db.storage.from("gallery").getPublicUrl(path);
    const url = pub?.data?.publicUrl;

    const sort_order = (await maxSort("gallery_items")) + 1;

    const { error } = await db.from("gallery_items").insert({
      url,
      caption: (gCaption.value || "").trim() || null,
      sort_order
    });

    gUploadBtn.disabled = false;

    if (error){
      setMsg(gMsg, "Saved image but DB insert failed.");
      return;
    }

    gFile.value = "";
    gCaption.value = "";
    setMsg(gMsg, "Uploaded.");
    await loadGallery();
  }

  async function loadGallery(){
    const { data, error } = await db.from("gallery_items").select("*").order("sort_order", { ascending: true });
    if (error){ gList.innerHTML = `<div class="muted small">Could not load gallery.</div>`; return; }

    gList.innerHTML = (data || []).map((it, idx)=>`
      <div class="row-item">
        <div class="row-left">
          <img class="thumb" src="${escapeHtml(it.url)}" alt="gallery" loading="lazy" />
          <div>
            <div class="small muted">#${idx+1}</div>
            <input class="inline-input" data-cap-id="${it.id}" value="${escapeHtml(it.caption || "")}" placeholder="Caption..." />
          </div>
        </div>
        <div class="row-actions">
          <button class="btn ghost smallbtn" data-up="${it.id}">↑</button>
          <button class="btn ghost smallbtn" data-down="${it.id}">↓</button>
          <button class="btn danger smallbtn" data-del="${it.id}">Delete</button>
        </div>
      </div>
    `).join("");

    // handlers
    gList.querySelectorAll("[data-cap-id]").forEach((inp)=>{
      inp.addEventListener("change", async ()=>{
        const id = inp.getAttribute("data-cap-id");
        await db.from("gallery_items").update({ caption: inp.value.trim() || null }).eq("id", id);
      });
    });

    gList.querySelectorAll("[data-del]").forEach((b)=>{
      b.addEventListener("click", async ()=>{
        const id = b.getAttribute("data-del");
        await db.from("gallery_items").delete().eq("id", id);
        await loadGallery();
      });
    });

    async function move(id, dir){
      const rows = (data || []).slice();
      const i = rows.findIndex(r=>r.id===id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= rows.length) return;

      const a = rows[i];
      const b = rows[j];
      await db.from("gallery_items").update({ sort_order: b.sort_order }).eq("id", a.id);
      await db.from("gallery_items").update({ sort_order: a.sort_order }).eq("id", b.id);
      await loadGallery();
    }

    gList.querySelectorAll("[data-up]").forEach((b)=>b.addEventListener("click", ()=>move(b.getAttribute("data-up"), -1)));
    gList.querySelectorAll("[data-down]").forEach((b)=>b.addEventListener("click", ()=>move(b.getAttribute("data-down"), +1)));
  }

  // ========= Page Blocks =========
  const pageSlug = document.getElementById("page-slug");
  const pageTitle = document.getElementById("page-title");
  const pageMd = document.getElementById("page-md");
  const savePageBtn = document.getElementById("save-page");
  const pageMsg = document.getElementById("page-msg");

  async function loadPageBlock(){
    const slug = pageSlug.value;
    const { data } = await db.from("pages").select("*").eq("slug", slug).maybeSingle();
    pageTitle.value = data?.title || "";
    pageMd.value = data?.content_md || "";
  }

  async function savePageBlock(){
    setMsg(pageMsg, "Saving...");
    const slug = pageSlug.value;
    const { error } = await db.from("pages").upsert({
      slug,
      title: pageTitle.value.trim() || null,
      content_md: pageMd.value.trim() || null
    }, { onConflict: "slug" });
    if (error){ setMsg(pageMsg, "Save failed."); return; }
    setMsg(pageMsg, "Saved.");
  }

  // ========= Prayer Requests (admin review) =========
  const prList = document.getElementById("pr-admin-list");
  const prMsg = document.getElementById("pr-admin-msg");

  async function loadPrayerAdmin(){
    const { data, error } = await db.from("prayer_requests").select("*").eq("status","pending").order("created_at", { ascending:false }).limit(50);
    if (error){ prList.innerHTML = `<div class="muted small">Could not load requests.</div>`; return; }

    if (!data || !data.length){
      prList.innerHTML = `<div class="muted small">No pending requests.</div>`;
      return;
    }

    prList.innerHTML = data.map((r)=>`
      <div class="row-item">
        <div class="row-left">
          <div>
            <div style="font-weight:800">${escapeHtml(r.name || "Anonymous")} ${r.category ? `<span class="pill">${escapeHtml(r.category)}</span>` : ""}</div>
            <div class="muted small">${new Date(r.created_at).toLocaleString()}</div>
            <div style="margin-top:6px; line-height:1.45">${escapeHtml(r.request_text)}</div>
          </div>
        </div>
        <div class="row-actions">
          <button class="btn primary smallbtn" data-approve="${r.id}">Approve</button>
          <button class="btn danger smallbtn" data-reject="${r.id}">Delete</button>
        </div>
      </div>
    `).join("");

    prList.querySelectorAll("[data-approve]").forEach((b)=>b.addEventListener("click", async ()=>{
      const id = b.getAttribute("data-approve");
      await db.from("prayer_requests").update({ status:"approved", approved_at: new Date().toISOString() }).eq("id", id);
      setMsg(prMsg, "Approved.");
      await loadPrayerAdmin();
    }));

    prList.querySelectorAll("[data-reject]").forEach((b)=>b.addEventListener("click", async ()=>{
      const id = b.getAttribute("data-reject");
      await db.from("prayer_requests").delete().eq("id", id);
      setMsg(prMsg, "Deleted.");
      await loadPrayerAdmin();
    }));
  }

  // ========= Sermons (admin) =========
  const sFile = document.getElementById("sermon-file");
  const sTitle = document.getElementById("sermon-title");
  const sDate = document.getElementById("sermon-date");
  const sPub = document.getElementById("sermon-published");
  const sDesc = document.getElementById("sermon-desc");
  const sUploadBtn = document.getElementById("sermon-upload-btn");
  const sMsg = document.getElementById("sermon-msg");
  const sList = document.getElementById("sermon-admin-list");

  async function uploadSermon(){
    const file = sFile.files && sFile.files[0];
    if (!file){ setMsg(sMsg, "Choose an audio or video file."); return; }
    const title = (sTitle.value || "").trim();
    if (!title){ setMsg(sMsg, "Enter a title."); return; }

    setMsg(sMsg, "Uploading...");
    sUploadBtn.disabled = true;

    const ext = (file.name.split(".").pop() || "mp4").toLowerCase();
    const path = `sermons/${crypto.randomUUID()}.${ext}`;

    const up = await db.storage.from("sermons").upload(path, file, { upsert: false, contentType: file.type });
    if (up.error){
      sUploadBtn.disabled = false;
      setMsg(sMsg, "Upload failed. Create bucket 'sermons' + policies.");
      return;
    }

    const pub = db.storage.from("sermons").getPublicUrl(path);
    const url = pub?.data?.publicUrl;

    const sort_order = (await maxSort("sermons")) + 1;

    const { error } = await db.from("sermons").insert({
      title,
      description: (sDesc.value || "").trim() || null,
      sermon_date: sDate.value ? new Date(sDate.value).toISOString().slice(0,10) : null,
      published: sPub.value === "true",
      url,
      media_type: file.type,
      sort_order
    });

    sUploadBtn.disabled = false;

    if (error){
      setMsg(sMsg, "Uploaded file but DB insert failed.");
      return;
    }

    sFile.value = "";
    sTitle.value = "";
    sDesc.value = "";
    setMsg(sMsg, "Uploaded.");
    await loadSermonsAdmin();
  }

  async function loadSermonsAdmin(){
    const { data, error } = await db.from("sermons").select("*").order("sort_order", { ascending:true }).order("created_at", { ascending:false }).limit(80);
    if (error){ sList.innerHTML = `<div class="muted small">Could not load sermons.</div>`; return; }

    if (!data || !data.length){
      sList.innerHTML = `<div class="muted small">No sermons yet.</div>`;
      return;
    }

    sList.innerHTML = data.map((s, idx)=>`
      <div class="row-item">
        <div class="row-left">
          <div>
            <div style="font-weight:800">${escapeHtml(s.title || "Sermon")} <span class="pill">${s.published ? "published" : "hidden"}</span></div>
            <div class="muted small">${s.sermon_date ? new Date(s.sermon_date).toLocaleDateString() : ""}</div>
            <div class="muted small">${escapeHtml(s.media_type || "")}</div>
          </div>
        </div>
        <div class="row-actions">
          <button class="btn ghost smallbtn" data-sup="${s.id}">↑</button>
          <button class="btn ghost smallbtn" data-sdown="${s.id}">↓</button>
          <button class="btn ghost smallbtn" data-toggle="${s.id}" data-pub="${s.published ? "1":"0"}">${s.published ? "Hide":"Publish"}</button>
          <button class="btn danger smallbtn" data-sdel="${s.id}">Delete</button>
        </div>
      </div>
    `).join("");

    async function move(id, dir){
      const rows = data.slice();
      const i = rows.findIndex(r=>r.id===id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= rows.length) return;
      const a = rows[i], b = rows[j];
      await db.from("sermons").update({ sort_order: b.sort_order }).eq("id", a.id);
      await db.from("sermons").update({ sort_order: a.sort_order }).eq("id", b.id);
      await loadSermonsAdmin();
    }

    sList.querySelectorAll("[data-sup]").forEach((b)=>b.addEventListener("click", ()=>move(b.getAttribute("data-sup"), -1)));
    sList.querySelectorAll("[data-sdown]").forEach((b)=>b.addEventListener("click", ()=>move(b.getAttribute("data-sdown"), +1)));

    sList.querySelectorAll("[data-toggle]").forEach((b)=>b.addEventListener("click", async ()=>{
      const id = b.getAttribute("data-toggle");
      const currently = b.getAttribute("data-pub") === "1";
      await db.from("sermons").update({ published: !currently }).eq("id", id);
      await loadSermonsAdmin();
    }));

    sList.querySelectorAll("[data-sdel]").forEach((b)=>b.addEventListener("click", async ()=>{
      const id = b.getAttribute("data-sdel");
      await db.from("sermons").delete().eq("id", id);
      await loadSermonsAdmin();
    }));
  }

  // ========= Init =========
  async function initAdmin(){
    await loadSettings();
    await loadGallery();
    await loadPageBlock();
    await loadPrayerAdmin();
    await loadSermonsAdmin();
  }

  if (loginBtn) loginBtn.addEventListener("click", login);
  if (logoutBtn) logoutBtn.addEventListener("click", logout);

  if (saveSettingsBtn) saveSettingsBtn.addEventListener("click", saveSettings);
  if (gUploadBtn) gUploadBtn.addEventListener("click", uploadGallery);

  if (pageSlug) pageSlug.addEventListener("change", loadPageBlock);
  if (savePageBtn) savePageBtn.addEventListener("click", savePageBlock);

  if (sUploadBtn) sUploadBtn.addEventListener("click", uploadSermon);

  // If already signed in, show app.
  showAppIfAdmin();

  // Keep UI in sync with auth changes (new tab sign-in/out)
  if (requireSupabase()){
    db.auth.onAuthStateChange(()=>showAppIfAdmin());
  }
})();
