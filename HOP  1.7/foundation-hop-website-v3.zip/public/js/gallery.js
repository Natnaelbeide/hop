
/* global db */
(async function(){
  const wrap = document.getElementById("gallery");
  const empty = document.getElementById("gallery-empty");
  if (!wrap) return;

  async function load(){
    wrap.innerHTML = "";
    empty.style.display = "none";

    const { data, error } = await db
      .from("gallery_items")
      .select("id,url,caption,sort_order")
      .order("sort_order", { ascending: true })
      .limit(200);

    if (error){
      empty.style.display = "block";
      empty.textContent = "Gallery could not load. Check Supabase settings.";
      return;
    }

    if (!data || data.length === 0){
      empty.style.display = "block";
      return;
    }

    for (const item of data){
      const el = document.createElement("div");
      el.className = "gallery-item";
      el.innerHTML = `
        <img loading="lazy" src="${item.url}" alt="${(item.caption||"Gallery image").replace(/"/g,'&quot;')}" />
        <div class="gallery-caption">${(item.caption || " ").replace(/</g,"&lt;")}</div>
      `;
      wrap.appendChild(el);
    }
  }

  await load();
})();
