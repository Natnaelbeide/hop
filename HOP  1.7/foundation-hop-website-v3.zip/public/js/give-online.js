/* global SiteData */
(function(){
  const stripeBtn = document.getElementById("stripe-btn");
  const stripeHint = document.getElementById("stripe-hint");
  const zelle = document.getElementById("zelle-id");
  const cash = document.getElementById("cashapp-id");

  async function init(){
    const s = await SiteData.getSettings();

    zelle.textContent = s.giving_zelle || "—";
    cash.textContent = s.giving_cashapp || "—";

    const stripeUrl = (s.giving_stripe_url || "").trim();
    if (stripeUrl){
      stripeBtn.href = stripeUrl;
      stripeHint.textContent = "Opens in a new tab.";
    } else {
      stripeBtn.href = "#";
      stripeBtn.classList.add("disabled");
      stripeBtn.addEventListener("click", (e)=>e.preventDefault());
      stripeHint.textContent = "Stripe link not configured yet (admin can add it).";
    }
  }

  init();
})();
