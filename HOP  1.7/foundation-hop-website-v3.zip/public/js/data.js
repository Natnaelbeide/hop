
/* global db */
window.SiteData = (function(){
  const defaults = {
    church_name: "Foundation of the Apostles and Prophets House of Prayer",
    address: "3846 King St Alexandria VA 22302",
    service_friday: "Friday Night 6:30 PM",
    service_sunday: "Sunday 3:00 PM",
    giving_zelle: "319-330-4590",
    giving_cashapp: "319-330-4590",
    giving_stripe_url: "",
    hero_cta: "Plan Your Visit",
    hero_subtitle: "A house of prayer for all nations — come worship with us."
  };

  async function getSetting(key){
    try{
      const { data, error } = await db.from("site_settings").select("value").eq("key", key).maybeSingle();
      if (error) throw error;
      if (!data) return defaults[key];
      return data.value ?? defaults[key];
    }catch(e){
      return defaults[key];
    }
  }

  async function getAll(keys){
    const out = {};
    await Promise.all(keys.map(async (k)=>{ out[k] = await getSetting(k); }));
    return out;
  }

  return { defaults, getSetting, getAll };
})();
