/* global supabase */
(function(){
  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // Works on Vercel (/) AND when opening files locally, AND inside /admin/
  const inAdmin = /\/admin\//.test(location.pathname);
  const ROOT = inAdmin ? "../" : "./";

  const isActive = (fileName) => {
    const p = (location.pathname || "").toLowerCase();
    return p.endsWith("/" + fileName) || p.endsWith(fileName);
  };

  const header = document.getElementById("site-header");
  if (header){
    header.innerHTML = `
      <div class="header">
        <div class="container">
          <div class="nav">
            <a class="brand" href="${ROOT}index.html" aria-label="Home">
              <img src="${ROOT}assets/logo.png" alt="Church logo" />
              <div>
                <div class="title">Foundation of the Apostles &amp; Prophets</div>
                <div class="subtitle">House of Prayer</div>
              </div>
            </a>

            <nav class="nav-links" aria-label="Primary">
              <a class="${isActive("index.html") ? "active" : ""}" href="${ROOT}index.html">Home</a>
              <a class="${isActive("service.html") ? "active" : ""}" href="${ROOT}service.html">Service</a>
              <a class="${isActive("giving.html") ? "active" : ""}" href="${ROOT}giving.html">Giving</a>
              <a class="${isActive("give-online.html") ? "active" : ""}" href="${ROOT}give-online.html">Give Online</a>
              <a class="${isActive("sermons.html") ? "active" : ""}" href="${ROOT}sermons.html">Sermons</a>
              <a class="${isActive("prayer.html") ? "active" : ""}" href="${ROOT}prayer.html">Prayer</a>
              <a class="${isActive("gallery.html") ? "active" : ""}" href="${ROOT}gallery.html">Gallery</a>
              <a class="${isActive("connect.html") ? "active" : ""}" href="${ROOT}connect.html">Connect</a>
              <a class="${isActive("tracker.html") ? "active" : ""}" href="${ROOT}tracker.html">Bible Tracker</a>
            </nav>
          </div>
        </div>
      </div>
    `;
  }

  // Section reveal animations (IntersectionObserver)
  function setupReveals(){
    const els = Array.from(document.querySelectorAll("[data-reveal]"));
    if (!els.length) return;

    const show = (el) => el.classList.add("reveal-show");
    if (!("IntersectionObserver" in window)){
      els.forEach(show);
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting){
          show(e.target);
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12 });
    els.forEach((el) => io.observe(el));
  }
  setupReveals();

  // Register service worker (only works on http/https, not file://)
  if ("serviceWorker" in navigator && location.protocol !== "file:"){
    window.addEventListener("load", () => {
      navigator.serviceWorker.register(ROOT + "sw.js").catch(()=>{});
    });
  }
})();
