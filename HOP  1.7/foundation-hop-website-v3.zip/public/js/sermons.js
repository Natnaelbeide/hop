/* global db */
(function(){
  const list = document.getElementById("sermon-list");
  const empty = document.getElementById("sermon-empty");
  const search = document.getElementById("sermon-search");
  const sort = document.getElementById("sermon-sort");

  let all = [];

  function escapeHtml(s){
    return (s || "").replace(/[&<>"']/g, (c)=>({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[c]));
  }

  function render(){
    const q = (search.value || "").trim().toLowerCase();
    const mode = sort.value;

    let rows = all.slice();
    rows = rows.filter(r => !q || (r.title || "").toLowerCase().includes(q));
    rows.sort((a,b)=>{
      const da = new Date(a.sermon_date || a.created_at || 0).getTime();
      const dbt = new Date(b.sermon_date || b.created_at || 0).getTime();
      return mode === "oldest" ? (da-dbt) : (dbt-da);
    });

    list.innerHTML = rows.map((s)=>{
      const title = escapeHtml(s.title || "Sermon");
      const desc = escapeHtml(s.description || "");
      const when = s.sermon_date ? new Date(s.sermon_date).toLocaleDateString() : "";
      const media = (s.media_type || "").startsWith("video")
        ? `<video controls preload="metadata" src="${escapeHtml(s.url)}"></video>`
        : `<audio controls preload="metadata" src="${escapeHtml(s.url)}"></audio>`;

      return `
        <article class="sermon-card">
          <div class="sermon-media">${media}</div>
          <div class="sermon-body">
            <div class="sermon-title">${title}</div>
            <div class="muted small">${when}</div>
            ${desc ? `<div class="sermon-desc">${desc}</div>` : ""}
          </div>
        </article>
      `;
    }).join("");

    empty.style.display = rows.length ? "none" : "block";
  }

  async function load(){
    if (!db || !window.SUPABASE_URL || window.SUPABASE_URL === "YOUR_SUPABASE_URL"){
      empty.style.display = "block";
      empty.textContent = "Connect Supabase to load sermons.";
      return;
    }

    const { data, error } = await db
      .from("sermons")
      .select("*")
      .eq("published", true)
      .order("sort_order", { ascending: true })
      .order("sermon_date", { ascending: false })
      .limit(60);

    if (error){
      empty.style.display = "block";
      empty.textContent = "Could not load sermons.";
      return;
    }

    all = data || [];
    render();
  }

  if (search) search.addEventListener("input", render);
  if (sort) sort.addEventListener("change", render);
  load();
})();
