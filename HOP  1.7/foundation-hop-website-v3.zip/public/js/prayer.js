/* global db */
(function(){
  const LS_KEY = "foundation_hop_device_id_v1";

  function getDeviceId(){
    let id = localStorage.getItem(LS_KEY);
    if (!id){
      id = "dev_" + crypto.randomUUID();
      localStorage.setItem(LS_KEY, id);
    }
    return id;
  }

  const els = {
    name: document.getElementById("pr-name"),
    cat: document.getElementById("pr-category"),
    text: document.getElementById("pr-text"),
    submit: document.getElementById("pr-submit"),
    msg: document.getElementById("pr-msg"),
    list: document.getElementById("pr-list"),
    empty: document.getElementById("pr-empty"),
  };

  function escapeHtml(s){
    return (s || "").replace(/[&<>"']/g, (c)=>({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[c]));
  }

  function card(item){
    const who = item.name ? escapeHtml(item.name) : "Anonymous";
    const cat = item.category ? `<span class="pill">${escapeHtml(item.category)}</span>` : "";
    const when = item.created_at ? new Date(item.created_at).toLocaleDateString() : "";
    return `
      <div class="req">
        <div class="req-top">
          <div class="req-who">${who} ${cat}</div>
          <div class="muted small">${when}</div>
        </div>
        <div class="req-text">${escapeHtml(item.request_text)}</div>
      </div>
    `;
  }

  async function loadApproved(){
    if (!db || !window.SUPABASE_URL || window.SUPABASE_URL === "YOUR_SUPABASE_URL"){
      els.empty.style.display = "block";
      els.empty.textContent = "Connect Supabase to load requests.";
      return;
    }

    const { data, error } = await db
      .from("prayer_requests")
      .select("*")
      .eq("status", "approved")
      .order("created_at", { ascending: false })
      .limit(40);

    if (error){
      els.empty.style.display = "block";
      els.empty.textContent = "Could not load requests.";
      return;
    }

    els.list.innerHTML = (data || []).map(card).join("");
    els.empty.style.display = (data && data.length) ? "none" : "block";
  }

  async function submit(){
    const request_text = (els.text.value || "").trim();
    const name = (els.name.value || "").trim();
    const category = (els.cat.value || "").trim();

    if (!request_text){
      els.msg.textContent = "Please write a request.";
      return;
    }

    if (!db || !window.SUPABASE_URL || window.SUPABASE_URL === "YOUR_SUPABASE_URL"){
      els.msg.textContent = "Supabase is not connected yet.";
      return;
    }

    els.submit.disabled = true;
    els.msg.textContent = "Submitting...";

    const payload = {
      device_id: getDeviceId(),
      name: name || null,
      category: category || null,
      request_text,
      status: "pending",
    };

    const { error } = await db.from("prayer_requests").insert(payload);

    els.submit.disabled = false;

    if (error){
      els.msg.textContent = "Submit failed. Please try again.";
      return;
    }

    els.text.value = "";
    els.msg.textContent = "Submitted! Your request will appear after review.";
  }

  if (els.submit) els.submit.addEventListener("click", submit);
  loadApproved();
})();
