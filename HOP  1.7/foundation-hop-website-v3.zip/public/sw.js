
const CACHE = "foundation-hop-v2";
const ASSETS = [
  "/",
  "/index.html",
  "/service.html",
  "/giving.html",
  "/gallery.html",
  "/connect.html",
  "/tracker.html",
  "/admin/dashboard.html",
  "/shepherd-portal.html",
  "/prayer.html",
  "/sermons.html",
  "/give-online.html",
  "/css/styles.css",
  "/js/shared.js",
  "/js/data.js",
  "/config/supabase.js",
  "/tracker/tracker.js",
  "/tracker/reading-plan.json",
  "/js/gallery.js",
  "/admin/admin.js",
  "/assets/logo.png",
  "/manifest.json",
  "/js/sermons.js",
  "/js/prayer.js",
  "/js/give-online.js",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(ASSETS)).then(()=>self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.map(k => k !== CACHE ? caches.delete(k) : null)))
      .then(()=>self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  const url = new URL(req.url);
  if (req.method !== "GET") return;

  // Network-first for Supabase API calls
  if (url.hostname.includes("supabase.co")){
    event.respondWith(fetch(req).catch(()=>caches.match(req)));
    return;
  }

  // Cache-first for everything else
  event.respondWith(
    caches.match(req).then((cached) => cached || fetch(req).then((res) => {
      const copy = res.clone();
      caches.open(CACHE).then((cache) => cache.put(req, copy));
      return res;
    }).catch(()=>cached))
  );
});
