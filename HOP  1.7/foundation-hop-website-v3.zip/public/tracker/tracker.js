
/* global db */
(function(){
  const LS_KEY = "foundation_hop_device_id_v1";

  function getDeviceId(){
    let id = localStorage.getItem(LS_KEY);
    if (!id){
      id = "dev_" + crypto.randomUUID();
      localStorage.setItem(LS_KEY, id);
    }
    return id;
  }

  async function fetchPlan(){
    const res = await fetch("tracker/reading-plan.json");
    if (!res.ok) throw new Error("reading-plan.json missing");
    return res.json();
  }

  async function loadProgress(deviceId){
    const { data } = await db.from("tracker_progress")
      .select("day,completed")
      .eq("device_id", deviceId);
    const map = new Map();
    (data || []).forEach(r => map.set(r.day, !!r.completed));
    return map;
  }

  async function loadNotes(deviceId){
    const { data } = await db.from("tracker_notes")
      .select("day,note")
      .eq("device_id", deviceId);
    const map = new Map();
    (data || []).forEach(r => map.set(r.day, r.note || ""));
    return map;
  }

  async function upsertProgress(deviceId, day, completed){
    await db.from("tracker_progress").upsert({
      device_id: deviceId,
      day,
      completed,
      completed_at: completed ? new Date().toISOString() : null
    }, { onConflict: "device_id,day" });
  }

  async function upsertNote(deviceId, day, note){
    await db.from("tracker_notes").upsert({
      device_id: deviceId,
      day,
      note,
      updated_at: new Date().toISOString()
    }, { onConflict: "device_id,day" });
  }

  function renderProgressBar(map){
    const total = 90;
    let done = 0;
    for (let d=1; d<=total; d++){
      if (map.get(d)) done++;
    }
    const pct = Math.round((done/total)*100);
    const bar = document.getElementById("progress-bar");
    if (bar) bar.style.width = pct + "%";
  }

  function escapeHtml(s){
    return (s || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  }

  async function main(){
    const deviceId = getDeviceId();
    const deviceEl = document.getElementById("device-id");
    if (deviceEl) deviceEl.textContent = deviceId;

    const [plan, progressMap, notesMap] = await Promise.all([
      fetchPlan(),
      loadProgress(deviceId),
      loadNotes(deviceId)
    ]);

    const grid = document.getElementById("tracker-grid");
    if (!grid) return;

    grid.innerHTML = "";
    for (const dayItem of plan.days){
      const day = dayItem.day;
      const completed = !!progressMap.get(day);
      const note = notesMap.get(day) || "";

      const el = document.createElement("div");
      el.className = "day-card";
      el.innerHTML = `
        <div class="inner">
          <div class="day-head">
            <div>
              <div class="day-title">Day ${day}</div>
              <div class="day-sub">
                <div><b>English:</b> ${escapeHtml(dayItem.english.join(" • "))}</div>
                <div><b>Tigrinya:</b> ${escapeHtml(dayItem.tigrinya.join(" • "))}</div>
              </div>
            </div>
            <label class="check" title="Mark complete">
              <input type="checkbox" ${completed ? "checked" : ""} />
              <span>Done</span>
            </label>
          </div>

          <textarea class="note" placeholder="Notes for Day ${day}...">${escapeHtml(note)}</textarea>

          <div class="day-actions">
            <button class="btn ghost save-btn" type="button">Save</button>
          </div>
        </div>
      `;

      const checkbox = el.querySelector("input[type=checkbox]");
      const textarea = el.querySelector("textarea");
      const saveBtn = el.querySelector(".save-btn");

      checkbox.addEventListener("change", async () => {
        progressMap.set(day, checkbox.checked);
        renderProgressBar(progressMap);
        await upsertProgress(deviceId, day, checkbox.checked);
      });

      saveBtn.addEventListener("click", async () => {
        saveBtn.textContent = "Saving…";
        saveBtn.disabled = true;
        await upsertNote(deviceId, day, textarea.value || "");
        saveBtn.textContent = "Saved";
        setTimeout(()=>{ saveBtn.textContent = "Save"; saveBtn.disabled = false; }, 700);
      });

      grid.appendChild(el);
    }

    renderProgressBar(progressMap);

    const resetBtn = document.getElementById("reset-btn");
    if (resetBtn){
      resetBtn.addEventListener("click", async () => {
        if (!confirm("Reset all progress and notes for this device?")) return;
        await db.from("tracker_progress").delete().eq("device_id", deviceId);
        await db.from("tracker_notes").delete().eq("device_id", deviceId);
        location.reload();
      });
    }
  }

  window.addEventListener("load", () => {
    main().catch((e) => {
      const grid = document.getElementById("tracker-grid");
      if (grid){
        grid.innerHTML = `<div class="notice">Tracker could not load. Check Supabase config in <span class="kbd">/config/supabase.js</span>.</div>`;
      }
      console.error(e);
    });
  });
})();
