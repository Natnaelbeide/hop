-- Enable required extension (usually already enabled)
-- create extension if not exists "pgcrypto";

create table if not exists public.site_settings (
  key text primary key,
  value text,
  updated_at timestamptz not null default now()
);

create table if not exists public.pages (
  slug text primary key,
  title text,
  content_md text,
  updated_at timestamptz not null default now()
);

create table if not exists public.gallery_items (
  id uuid primary key default gen_random_uuid(),
  url text not null,
  caption text,
  sort_order int not null default 1,
  created_at timestamptz not null default now()
);

create table if not exists public.tracker_progress (
  device_id text not null,
  day int not null check (day >= 1 and day <= 90),
  completed boolean not null default false,
  completed_at timestamptz,
  primary key (device_id, day)
);

create table if not exists public.tracker_notes (
  device_id text not null,
  day int not null check (day >= 1 and day <= 90),
  note text,
  updated_at timestamptz not null default now(),
  primary key (device_id, day)
);


create table if not exists public.prayer_requests (
  id uuid primary key default gen_random_uuid(),
  device_id text,
  name text,
  category text,
  request_text text not null,
  status text not null default 'pending' check (status in ('pending','approved')),
  created_at timestamptz not null default now(),
  approved_at timestamptz
);

create table if not exists public.sermons (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  sermon_date date,
  url text not null,
  media_type text,
  published boolean not null default true,
  sort_order int not null default 1,
  created_at timestamptz not null default now()
);

-- RLS
alter table public.site_settings enable row level security;
alter table public.pages enable row level security;
alter table public.gallery_items enable row level security;
alter table public.tracker_progress enable row level security;
alter table public.tracker_notes enable row level security;
alter table public.prayer_requests enable row level security;
alter table public.sermons enable row level security;

-- Public read policies
create policy "public read site_settings"
on public.site_settings for select
to anon, authenticated
using (true);

create policy "public read pages"
on public.pages for select
to anon, authenticated
using (true);

create policy "public read gallery"
on public.gallery_items for select
to anon, authenticated
using (true);

-- Tracker: allow anonymous per-device tracking (no login)
create policy "public read tracker_progress"
on public.tracker_progress for select
to anon, authenticated
using (true);

create policy "public write tracker_progress"
on public.tracker_progress for insert
to anon, authenticated
with check (true);

create policy "public update tracker_progress"
on public.tracker_progress for update
to anon, authenticated
using (true)
with check (true);

create policy "public delete tracker_progress"
on public.tracker_progress for delete
to anon, authenticated
using (true);

create policy "public read tracker_notes"
on public.tracker_notes for select
to anon, authenticated
using (true);

create policy "public write tracker_notes"
on public.tracker_notes for insert
to anon, authenticated
with check (true);

create policy "public update tracker_notes"
on public.tracker_notes for update
to anon, authenticated
using (true)
with check (true);

create policy "public delete tracker_notes"
on public.tracker_notes for delete
to anon, authenticated
using (true);


-- Prayer requests: public can submit, public can read approved only
create policy "public read approved prayer"
on public.prayer_requests for select
to anon, authenticated
using (status = 'approved');

create policy "public submit prayer"
on public.prayer_requests for insert
to anon, authenticated
with check (status = 'pending');

-- Sermons: public can read published sermons
create policy "public read sermons"
on public.sermons for select
to anon, authenticated
using (published = true);


-- Admin write policies (ONLY the configured admin email can edit)
create policy "admin write site_settings"
on public.site_settings for all
to authenticated
using ((auth.jwt() ->> 'email') = 'beidenatnael@gmail.com')
with check ((auth.jwt() ->> 'email') = 'beidenatnael@gmail.com');

create policy "admin write pages"
on public.pages for all
to authenticated
using ((auth.jwt() ->> 'email') = 'beidenatnael@gmail.com')
with check ((auth.jwt() ->> 'email') = 'beidenatnael@gmail.com');

create policy "admin write gallery"
on public.gallery_items for all
to authenticated
using ((auth.jwt() ->> 'email') = 'beidenatnael@gmail.com')
with check ((auth.jwt() ->> 'email') = 'beidenatnael@gmail.com');


create policy "admin write prayer_requests"
on public.prayer_requests for all
to authenticated
using ((auth.jwt() ->> 'email') = 'beidenatnael@gmail.com')
with check ((auth.jwt() ->> 'email') = 'beidenatnael@gmail.com');

create policy "admin write sermons"
on public.sermons for all
to authenticated
using ((auth.jwt() ->> 'email') = 'beidenatnael@gmail.com')
with check ((auth.jwt() ->> 'email') = 'beidenatnael@gmail.com');
