-- Storage policies for bucket "gallery"
-- Note: you must create the bucket in the Dashboard first.

-- Public read for objects in gallery bucket
create policy "public read gallery objects"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'gallery');

-- Admin can upload/update/delete objects in gallery bucket
create policy "admin write gallery objects"
on storage.objects for all
to authenticated
using (
  bucket_id = 'gallery'
  and (auth.jwt() ->> 'email') = 'beidenatnael@gmail.com'
)
with check (
  bucket_id = 'gallery'
  and (auth.jwt() ->> 'email') = 'beidenatnael@gmail.com'
);


-- Storage policies for bucket "sermons"
-- Note: you must create the bucket in the Dashboard first.

-- Public read for objects in sermons bucket
create policy "public read sermons objects"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'sermons');

-- Admin can upload/update/delete objects in sermons bucket
create policy "admin write sermons objects"
on storage.objects for all
to authenticated
using (
  bucket_id = 'sermons'
  and (auth.jwt() ->> 'email') = 'beidenatnael@gmail.com'
)
with check (
  bucket_id = 'sermons'
  and (auth.jwt() ->> 'email') = 'beidenatnael@gmail.com'
);
