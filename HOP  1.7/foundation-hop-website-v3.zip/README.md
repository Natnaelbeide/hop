# Foundation of the Apostles and Prophets House of Prayer — Website + PWA

This is a **static (no-build)** website designed to deploy on **Vercel** and use **Supabase** for:
- live content updates (no redeploy)
- admin dashboard
- gallery (Supabase Storage + DB)
- 90‑Day Bible reading tracker (per-device progress)

## Project structure

```
/public
  index.html
  service.html
  giving.html
  gallery.html
  connect.html
  tracker.html
  /css/styles.css
  /js/shared.js
  /js/data.js
  /js/gallery.js
  /assets/logo.png
  /config/supabase.js
  /admin/dashboard.html
  /admin/admin.js
  /tracker/tracker.js
  /tracker/reading-plan.json
  manifest.json
  sw.js
```

## 1) Supabase setup

### A) Create a Supabase project
- Create a new project at Supabase.
- Copy:
  - **Project URL**
  - **Anon public key**

Paste them into: `public/config/supabase.js`

### B) Create the admin user
In Supabase Dashboard → **Authentication → Users**
- Create a user with email: **beidenatnael@gmail.com**
- Set password: **Jesus@hop**

The dashboard login is:
- Username: **HOPadmin**
- Password: **Jesus@hop**

### C) Create DB tables + policies

Run the SQL in `supabase/schema.sql` (Dashboard → SQL Editor).

### D) Create Storage bucket for gallery
Dashboard → **Storage → New bucket**
- name: `gallery`
- public: ✅ ON

Then run the SQL in `supabase/storage_policies.sql`.

## 2) Local testing

Because it’s a static site, you can serve it with any static server from the `public` folder.

Example (VS Code Live Server) or:

```bash
cd public
python -m http.server 5173
```

Then open:
- http://localhost:5173/index.html

## 3) Vercel deployment

Vercel → New Project → Import → select this folder

Settings:
- Framework Preset: **Other**
- Build Command: **None**
- Output Directory: **public**

Deploy.

## Notes

- The **90‑day reading plan dataset** is stored in `public/tracker/reading-plan.json`.
- Progress is saved in Supabase using a **device_id** stored in browser localStorage.



## New pages
- `give-online.html` (Stripe + Zelle/CashApp)
- `sermons.html` (public sermon library)
- `prayer.html` (public prayer board + submit form)
- Secret admin entry: `shepherd-portal.html` (redirects to admin dashboard; not linked in navigation)

## Activate Supabase (step-by-step)

### 1) Create a Supabase project
- Go to Supabase dashboard → **New project**
- After it finishes, copy:
  - **Project URL**
  - **anon public key**

### 2) Add your Supabase keys to the website
Open:

`/public/config/supabase.js`

Replace:

- `YOUR_SUPABASE_URL`
- `YOUR_SUPABASE_ANON_KEY`

### 3) Create the database tables + policies
Supabase Dashboard → **SQL Editor** → run:

1) `supabase/schema.sql`
2) `supabase/storage_policies.sql`

### 4) Create Storage buckets
Supabase Dashboard → **Storage** → **Create bucket**
- Bucket name: `gallery`
- Public bucket: ✅ ON

Create another bucket:
- Bucket name: `sermons`
- Public bucket: ✅ ON

(Policies in `storage_policies.sql` will control admin upload/delete.)

### 5) Create the Admin Auth user
Supabase Dashboard → **Authentication** → **Users** → **Add user**
- Email: `beidenatnael@gmail.com`
- Password: (use your admin password)

Only this email will be allowed into the Admin dashboard (enforced by RLS + client check).

### 6) Open the Admin portal
For extra security the Admin page is not linked in the site header.

Open:
- `/shepherd-portal.html`

Login with the admin email + password you created in Supabase.

### 7) Add your Stripe payment link
In Admin → **Site Settings**:
- Paste your **Stripe Payment Link** into **Stripe Payment Link (Give Online)**

This powers the button on:
- `/give-online.html`

## Notes
- The Prayer Requests page uses a “review first” workflow:
  - Visitors submit requests (status = pending)
  - Admin approves them (status = approved) before they show publicly
- Sermons are uploaded to the `sermons` Storage bucket and listed automatically on `/sermons.html`
